package com.example.e_tiffin.Common;

import com.example.e_tiffin.Model.User;

public class Common {

    public static User currentUser;
}
