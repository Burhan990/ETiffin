package com.example.e_tiffin;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.graphics.Typeface;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {

    private Button sign_Up,sign_In;
    private TextView txtslogan;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        sign_Up=(Button)findViewById(R.id.btnSignUp);
        sign_In=(Button)findViewById(R.id.btnLogIn);

        txtslogan=(TextView)findViewById(R.id.textSlogan);

        Typeface face=Typeface.createFromAsset(getAssets(),"fonts/fonts.TTF");
        txtslogan.setTypeface(face);


        sign_Up.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                Intent intent=new Intent(MainActivity.this,SignUp.class);
                startActivity(intent);

            }
        });


        sign_In.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                Intent intent=new Intent(MainActivity.this,SignIn.class);
                startActivity(intent);

            }
        });

    }
}
